import React from "react";

export function Header() {
    return (
        <header style={{ background: "#282c34", padding: "1rem", color: "white" }}>
            <h1>Bienvenue sur mon projet React avec Vite 🚀</h1>
        </header>
    );
}