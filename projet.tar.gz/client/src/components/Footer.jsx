import React from "react";

export function Footer() {
    return (
        <footer className="footer">
            <p>© 2025 - Mon projet React avec Vite</p>
        </footer>
    );
}
